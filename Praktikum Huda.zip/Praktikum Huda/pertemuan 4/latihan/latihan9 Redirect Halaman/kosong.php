<?php
echo "Data kosong";
?>