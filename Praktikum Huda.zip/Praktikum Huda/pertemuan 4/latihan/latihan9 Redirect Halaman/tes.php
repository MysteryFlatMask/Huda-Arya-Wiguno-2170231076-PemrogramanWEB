<?php
echo "Page dialihkan"
?>