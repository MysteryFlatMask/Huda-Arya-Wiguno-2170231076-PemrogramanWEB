<html>
    <head>
        <title>Aplikasi Sederhana Menghitung Luas Persegi Panjang</title>
    </head>
    <body>
        <?php
        $panjang = 100;
        $lebar = 55;
        $luas = $panjang * $lebar;
        echo "hasil dari panjang ($panjang) * lebar ($lebar) adalah = $luas"; echo "<br>";
        ?> 
    </body>
</html>