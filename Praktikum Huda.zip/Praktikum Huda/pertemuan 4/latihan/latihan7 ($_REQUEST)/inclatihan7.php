<?php
$angka=90;
?>