<?php
if (isset($varible_cookies)) {
    echo 'Variable cookienya "$variable_cookies" nilainya adalah' .$variable_cookies;
} else {
    echo "Variable cookies belum diterapkan";
}
?>