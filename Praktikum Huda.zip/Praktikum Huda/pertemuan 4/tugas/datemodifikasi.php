<html lang="in">
    <head>
        <title>Tanggalan Modifikasi</title>
    </head>
    <body>
        <?php
        echo date("l, j F Y, H:i:s a"); ?>
    </body>
</html>